/*DROP DATABASE IF EXISTS uebungsdatenbank;*/
CREATE DATABASE uebungsdatenbank
    WITH 
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'German_Germany.1252'
    LC_CTYPE = 'German_Germany.1252'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;

